import json
import requests
import pandas as pd

df = pd.read_csv('./penguindata_test.csv')

header = {'Content-Type': 'application/json', \
                  'Accept': 'application/json'}
data = df.drop('PassengerId', axis = 1).to_json(orient='records')


resp = requests.post("http://127.0.0.1:8000/api/classification/", \
                    data = json.dumps(data),\
                    headers= header)


print (resp)
df['Survived'] = resp.json()

print(df.head(10))
